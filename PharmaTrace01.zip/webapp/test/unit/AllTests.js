sap.ui.define([
	"com/sap/PharmaTrace01/test/unit/controller/lookup.controller"
], function () {
	"use strict";
});