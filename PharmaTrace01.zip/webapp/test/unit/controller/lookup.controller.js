/*global QUnit*/

sap.ui.define([
	"com/sap/PharmaTrace01/controller/lookup.controller"
], function (Controller) {
	"use strict";

	QUnit.module("lookup Controller");

	QUnit.test("I should test the lookup controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});