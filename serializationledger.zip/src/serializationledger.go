package main

import (
	"encoding/json"
	"errors"
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

var logger = shim.NewLogger("CLDChaincode")

// The type for the chaincode
type SerializationLedger struct {
}

// Serial attributes
type Serial struct {
	ID                string `json:"ID"`
	AssetType         string `json:"assetType"`
	Manufacturer      string `json:"manufacturer"`
	BatchNo           string `json:"batchNo"`
	SerialNo          string `json:"serialNo"`
	ManufacturingDate string `json:"manufacturingDate"`
	ScanNo            string `json:"scanNo"`
	ScanBy            string `json:"scanBy"`
	Alias             string `json:"alias"`
}

// LedgerIDIndex - Index on IDs for retrieval all Medicines
type LedgerIDIndex struct {
	IDs []string `json:"IDs"`
}

func main() {
	err := shim.Start(new(SerializationLedger))
	if err != nil {
		fmt.Printf("Error starting SerializationLedger chaincode function main(): %s", err)
	} else {
		fmt.Printf("Starting SerializationLedger chaincode function main() executed successfully")
	}
}

// Init - The chaincode Init function: No  arguments, only initializes a ID array as Index for retrieval of all Serials
func (ledger *SerializationLedger) Init(stub shim.ChaincodeStubInterface) peer.Response {
	var ledgerIDIndex LedgerIDIndex
	record, _ := stub.GetState("ledgerIDIndex")
	// chaincode upgrade: Index might already exist, create new only if it does not
	if record == nil {
		bytes, _ := json.Marshal(ledgerIDIndex)
		stub.PutState("ledgerIDIndex", bytes)
	}
	return shim.Success(nil)
}

// Invoke - The chaincode Invoke function:
func (ledger *SerializationLedger) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	function, args := stub.GetFunctionAndParameters()
	logger.Debug("function: ", function)
	switch function {
	case "addNewSerial":
		return ledger.addNewSerial(stub, args)
	case "removeSerial":
		return ledger.removeSerial(stub, args[0])
	case "removeAllSerials":
		return ledger.removeAllSerials(stub)
	case "readSerial":
		return ledger.readSerial(stub, args[0])
	case "readAllSerials":
		return ledger.readAllSerials(stub)
	default:
		return shim.Error("unknown function invocation")
	}
}

// Invoke Route: addNewSerial
func (ledger *SerializationLedger) addNewSerial(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	serial, err := getSerialFromArgs(args)
	if err != nil {
		return shim.Error("serial Data is Corrupted")
	}
	serial.AssetType = "Asset.Serial"
	record, err := stub.GetState(serial.ID)
	if record != nil {
		return shim.Error("serial already exists: " + serial.ID)
	}
	_, err = ledger.saveSerial(stub, serial)
	if err != nil {
		return shim.Error(err.Error())
	}
	_, err = ledger.updateLedgerIDIndex(stub, serial)
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(nil)
}

// Invoke Route: removeSerial
func (ledger *SerializationLedger) removeSerial(stub shim.ChaincodeStubInterface, serialId string) peer.Response {
	_, err := ledger.deleteSerial(stub, serialId)
	if err != nil {
		return shim.Error(err.Error())
	}
	_, err = ledger.deleteSerialFromIndex(stub, serialId)
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(nil)
}

// Invoke Route: removeAllSerials
func (ledger *SerializationLedger) removeAllSerials(stub shim.ChaincodeStubInterface) peer.Response {
	var ledgerIDIndex LedgerIDIndex
	bytes, err := stub.GetState("ledgerIDIndex")
	if err != nil {
		return shim.Error("removeAllSerials: Error getting ledgerIDIndex array")
	}
	err = json.Unmarshal(bytes, &ledgerIDIndex)
	if err != nil {
		return shim.Error("removeAllSerials: Error unmarshalling ledgerIDIndex array JSON")
	}
	if len(ledgerIDIndex.IDs) == 0 {
		return shim.Error("removeAllSerials: No serials to remove")
	}
	for _, serialId := range ledgerIDIndex.IDs {
		_, err = ledger.deleteSerial(stub, serialId)
		if err != nil {
			return shim.Error("Failed to remove Serial with ID: " + serialId)
		}
		_, err = ledger.deleteSerialFromIndex(stub, serialId)
		if err != nil {
			return shim.Error(err.Error())
		}
	}
	ledger.initHolder(stub)
	return shim.Success(nil)
}

// Query Route: readSerial
func (ledger *SerializationLedger) readSerial(stub shim.ChaincodeStubInterface, serialId string) peer.Response {
	serialAsByteArray, err := ledger.retrieveSerial(stub, serialId)
	if err != nil {
		return shim.Error(err.Error())
	}
	return shim.Success(serialAsByteArray)
}

// Query Route: readAllSerials
func (ledger *SerializationLedger) readAllSerials(stub shim.ChaincodeStubInterface) peer.Response {
	var ledgerIDIndex LedgerIDIndex
	bytes, err := stub.GetState("ledgerIDIndex")
	if err != nil {
		return shim.Error("readAllSerials: Error getting ledgerIDIndex array")
	}
	err = json.Unmarshal(bytes, &ledgerIDIndex)
	if err != nil {
		return shim.Error("readAllSerials: Error unmarshalling ledgerIDIndex array JSON")
	}
	result := "["

	var serialAsByteArray []byte

	for _, serialId := range ledgerIDIndex.IDs {
		serialAsByteArray, err = ledger.retrieveSerial(stub, serialId)
		if err != nil {
			return shim.Error("failed to retrieve serial with ID: " + serialId)
		}
		result += string(serialAsByteArray) + ","
	}
	if len(result) == 1 {
		result = "[]"
	} else {
		result = result[:len(result)-1] + "]"
	}
	return shim.Success([]byte(result))
}

// Helper: Save serials
func (ledger *SerializationLedger) saveSerial(stub shim.ChaincodeStubInterface, serial Serial) (bool, error) {
	bytes, err := json.Marshal(serial)
	if err != nil {
		return false, errors.New("error converting serial record JSON")
	}
	err = stub.PutState(serial.ID, bytes)
	if err != nil {
		return false, errors.New("error storing Serial record")
	}
	return true, nil
}

// Helper: Delete serial
func (ledger *SerializationLedger) deleteSerial(stub shim.ChaincodeStubInterface, serialId string) (bool, error) {
	_, err := ledger.retrieveSerial(stub, serialId)
	if err != nil {
		return false, errors.New("serial with ID: " + serialId + " not found")
	}
	err = stub.DelState(serialId)
	if err != nil {
		return false, errors.New("error deleting Serial record")
	}
	return true, nil
}

// Helper: Update serials index - updates Index
func (ledger *SerializationLedger) updateLedgerIDIndex(stub shim.ChaincodeStubInterface, serial Serial) (bool, error) {
	var ledgerIDIndex LedgerIDIndex
	bytes, err := stub.GetState("ledgerIDIndex")
	if err != nil {
		return false, errors.New("updateLedgerIDIndex: Error getting ledgerIDIndex array Index from state")
	}
	err = json.Unmarshal(bytes, &ledgerIDIndex)
	if err != nil {
		return false, errors.New("updateLedgerIDIndex: Error unmarshalling ledgerIDIndex array JSON")
	}
	ledgerIDIndex.IDs = append(ledgerIDIndex.IDs, serial.ID)
	bytes, err = json.Marshal(ledgerIDIndex)
	if err != nil {
		return false, errors.New("updateLedgerIDIndex: Error marshalling new serial ID")
	}
	err = stub.PutState("ledgerIDIndex", bytes)
	if err != nil {
		return false, errors.New("updateLedgerIDIndex: Error storing new serial ID in ledgerIDIndex (Index)")
	}
	return true, nil
}

// Helper: delete ID from serial index
func (ledger *SerializationLedger) deleteSerialFromIndex(stub shim.ChaincodeStubInterface, serialId string) (bool, error) {
	var ledgerIDIndex LedgerIDIndex
	bytes, err := stub.GetState("ledgerIDIndex")
	if err != nil {
		return false, errors.New("deleteSerialFromIndex: Error getting ledgerIDIndex array Index from state")
	}
	err = json.Unmarshal(bytes, &ledgerIDIndex)
	if err != nil {
		return false, errors.New("deleteSerialFromIndex: Error unmarshalling ledgerIDIndex array JSON")
	}
	ledgerIDIndex.IDs, err = deleteKeyFromStringArray(ledgerIDIndex.IDs, serialId)
	if err != nil {
		return false, errors.New(err.Error())
	}
	bytes, err = json.Marshal(ledgerIDIndex)
	if err != nil {
		return false, errors.New("deleteSerialFromIndex: Error marshalling new serial ID")
	}
	err = stub.PutState("ledgerIDIndex", bytes)
	if err != nil {
		return false, errors.New("deleteSerialFromIndex: Error storing new serial ID in ledgerIDIndex (Index)")
	}
	return true, nil
}

// Helper: Initialize serials ID Index
func (ledger *SerializationLedger) initHolder(stub shim.ChaincodeStubInterface) bool {
	var ledgerIDIndex LedgerIDIndex
	bytes, _ := json.Marshal(ledgerIDIndex)
	stub.DelState("ledgerIDIndex")
	stub.PutState("ledgerIDIndex", bytes)
	return true
}

// Helper: Retrieve serial
func (ledger *SerializationLedger) retrieveSerial(stub shim.ChaincodeStubInterface, serialId string) ([]byte, error) {
	var serial Serial
	var serialAsByteArray []byte
	bytes, err := stub.GetState(serialId)
	if err != nil {
		return serialAsByteArray, errors.New("retrieveSerial: Error retrieving serial with ID: " + serialId)
	}
	err = json.Unmarshal(bytes, &serial)
	if err != nil {
		return serialAsByteArray, errors.New("retrieveSerial: Corrupt serial record " + string(bytes))
	}
	serialAsByteArray, err = json.Marshal(serial)
	if err != nil {
		return serialAsByteArray, errors.New("readSerial: Invalid serial Object - Not a  valid JSON")
	}
	return serialAsByteArray, nil
}

// deleteKeyFromArray
func deleteKeyFromStringArray(array []string, key string) (newArray []string, err error) {
	for _, entry := range array {
		if entry != key {
			newArray = append(newArray, entry)
		}
	}
	if len(newArray) == len(array) {
		return newArray, errors.New("Specified Key: " + key + " not found in Array")
	}
	return newArray, nil
}

// getSerialFromArgs - construct a serial structure from string array of arguments
func getSerialFromArgs(args []string) (serial Serial, err error) {

	if !Valid(args[0]) {
		return serial, errors.New("invalid json")
	}

	err = Unmarshal([]byte(args[0]), &serial)
	if err != nil {
		return serial, err
	}
	return serial, nil
}
